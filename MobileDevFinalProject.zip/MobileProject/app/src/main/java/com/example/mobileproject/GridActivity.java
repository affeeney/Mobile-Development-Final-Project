package com.example.mobileproject;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.mobileproject.R;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class GridActivity extends AppCompatActivity {

    private List<String> items = new ArrayList<>();
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid);


        GridView gridView = findViewById(R.id.gridView);
        items = getProducts();

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
        gridView.setAdapter(adapter);


        EditText itemNameField = findViewById(R.id.itemNameField);
        EditText itemQuantityField = findViewById(R.id.itemQuantityField);
        Button addItemButton = findViewById(R.id.addItemButton);

        addItemButton.setOnClickListener(v -> {
            String itemName = itemNameField.getText().toString().trim();
            String itemQuantity = itemQuantityField.getText().toString().trim();

            if (!itemName.isEmpty() && !itemQuantity.isEmpty()) {

                addProduct(itemName, Integer.parseInt(itemQuantity));
                items.clear();
                items.addAll(getProducts());
                adapter.notifyDataSetChanged();
                itemNameField.setText("");
                itemQuantityField.setText("");
            } else {
                Toast.makeText(this, "enter item and amount", Toast.LENGTH_SHORT).show();
            }
        });


        gridView.setOnItemClickListener((AdapterView<?> parent, View view, int position, long id) -> {
            String selectedItem = items.get(position);
            String itemName = selectedItem.split(" - ")[0];
            removeProduct(itemName);
            items.clear();
            items.addAll(getProducts());
            adapter.notifyDataSetChanged();
            Toast.makeText(this, "item removed", Toast.LENGTH_SHORT).show();
        });
    }
    //CRUD functionalities for the database
    private List<String> getProducts() {
        List<String> items = new ArrayList<>();
        try (Connection connection = DatabaseHelper.connect();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM Items");
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                items.add(resultSet.getString("name") + " - " + resultSet.getInt("quantity"));
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return items;
    }
    private void addProduct(String name, int quantity) {
        try (Connection connection = DatabaseHelper.connect();
             PreparedStatement statement = connection.prepareStatement("INSERT INTO Items (name, quantity) VALUES (?, ?)")) {
            statement.setString(1, name);
            statement.setInt(2, quantity);
            statement.executeUpdate();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void updateProduct(String name, int quantity) {
        try (Connection connection = DatabaseHelper.connect();
             PreparedStatement statement = connection.prepareStatement("UPDATE Items SET quantity = ? WHERE name = ?")) {
            statement.setInt(1, quantity);
            statement.setString(2, name);
            statement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void removeProduct(String name) {
        try (Connection connection = DatabaseHelper.connect();
             PreparedStatement statement = connection.prepareStatement("DELETE FROM Items WHERE name = ?")) {
            statement.setString(1, name);
            statement.executeUpdate();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }



}


